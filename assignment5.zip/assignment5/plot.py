import networkx as nx
import matplotlib.pyplot as plt

with open('input.txt', 'r') as f:
    no_of_nodes, no_of_edges = f.readline().split()
    print(no_of_nodes, no_of_edges)
    edges = list()
    for line in f:
        from_node, to_node, _, _ = line.split()
        edges.append((from_node, to_node))
        
    G = nx.DiGraph()
    G.add_edges_from(edges)
